package model.abilities;

public enum AreaOfEffect {
	SELFTARGET,SINGLETARGET,TEAMTARGET,DIRECTIONAL,SURROUND;

}