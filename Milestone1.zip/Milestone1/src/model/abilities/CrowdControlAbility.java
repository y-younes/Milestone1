package model.abilities;

import model.effects.Effect;

public class CrowdControlAbility extends Ability {
	private Effect effect;

	

	public CrowdControlAbility(String name, int manaCost, int baseCooldown, int castRange, AreaOfEffect castArea,
			int requiredActionPoints, Effect effect) {
		super(name, manaCost, baseCooldown, castRange, castArea, requiredActionPoints);
		this.effect = effect;
	}



	public Effect getEffect() {
		return effect;
	}
	
	

}