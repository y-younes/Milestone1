package model.effects;

public class Dodge extends Effect {
	/*public Dodge(String name, int duration) {
		super(name, duration,EffectType.BUFF);
		
	}*/
	public Dodge(int duration) {
		super("Dodge", duration,EffectType.BUFF);
		
	}

}