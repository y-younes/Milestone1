package model.effects;

public class Embrace extends Effect {
	public Embrace(String name, int duration, EffectType type) {
		super(name, duration,EffectType.BUFF);
		
	}

}