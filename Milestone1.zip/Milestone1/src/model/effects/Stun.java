package model.effects;

public class Stun extends Effect {
	public Stun(String name, int duration, EffectType type) {
		super(name, duration,EffectType.DEBUFF);
		
	}

}