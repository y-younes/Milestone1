package model.world;

public enum Direction {
	RIGHT,LEFT,UP,DOWN

}