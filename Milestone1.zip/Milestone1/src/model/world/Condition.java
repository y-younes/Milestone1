package model.world;

public enum Condition {
	ACTIVE,INACTIVE,KNOCKEDOUT,ROOTED;

}