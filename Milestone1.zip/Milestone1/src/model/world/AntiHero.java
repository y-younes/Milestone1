package model.world;

public class AntiHero extends Champion {
	public AntiHero(String name, int maxHP, int mana, int maxActions, int speed, int attackRange,
			int attackDamage){
		super(name, maxHP, mana, maxActions, speed,  attackRange,attackDamage);
	}

}