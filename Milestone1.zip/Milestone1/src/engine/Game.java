package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Disarm;
import model.effects.Dodge;
import model.effects.Effect;
import model.effects.EffectType;
import model.effects.Embrace;
import model.effects.PowerUp;
import model.effects.Root;
import model.effects.Shield;
import model.effects.Shock;
import model.effects.Silence;
import model.effects.SpeedUp;
import model.effects.Stun;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Hero;
import model.world.Villain;

public class Game {
	private Player firstPlayer;
	private Player secondPlayer;
	private boolean firstLeaderAbilityUsed;
	private boolean secondLeaderAbilityUsed;
	private Object[][] board;
	private static ArrayList<Champion> availableChampions;
	private static ArrayList<Ability> availableAbilities;
	private PriorityQueue turnOrder;
	final private static int BOARDHEIGHT = 5;
	final private static int BOARDWIDTH = 5;
	
	public Game(Player first, Player second)
	{
		this.firstPlayer = first;
		this.secondPlayer = second;
		//this.board = new Object[5][5];
		availableChampions = new ArrayList<Champion>();
		availableAbilities = new ArrayList<Ability>();
		board = new Object[BOARDHEIGHT][BOARDWIDTH];
		turnOrder = new PriorityQueue(6);
		//place covers and champions
		placeChampions();
		placeCovers();
		
	}
	
	private void placeChampions()
	{
		
		//for (int i=0; i< firstPlayer.getTeam().size(); i++ ){
			//firstPlayer.getTeam().get(i).setLocation(new Point(0,i+1));
			//board[0][i+1] = firstPlayer.getTeam().get(0);
		//}
		//for (int j=0; j< secondPlayer.getTeam().size(); j++){
			//secondPlayer.getTeam().get(j).setLocation(new Point(4,j+1));
			//board[4][j+1] = secondPlayer.getTeam().get(j);
		//}
		/*if(firstPlayer.getTeam().get(0)!=null)
		{
		firstPlayer.getTeam().get(0).setLocation(new Point(0,1));
		board[0][1] = firstPlayer.getTeam().get(0);
		}
		if (firstPlayer.getTeam().get(1)!= null)
		{
		firstPlayer.getTeam().get(1).setLocation(new Point(0,2));
		board[0][2] = firstPlayer.getTeam().get(1);
		}
		if (firstPlayer.getTeam().get(2)!= null)
		{
		firstPlayer.getTeam().get(2).setLocation(new Point(0,3));
		board[0][3] = firstPlayer.getTeam().get(2);
		}
		if(secondPlayer.getTeam().get(0)!= null)
		{
		secondPlayer.getTeam().get(0).setLocation(new Point(4,1));
		board[4][1] = secondPlayer.getTeam().get(0);
		}
		if (secondPlayer.getTeam().get(1)!= null)
		{
		secondPlayer.getTeam().get(1).setLocation(new Point(4,2));
		board[4][2] = secondPlayer.getTeam().get(1);
		}
		if (secondPlayer.getTeam().get(2)!= null)
		{
		secondPlayer.getTeam().get(2).setLocation(new Point(4,3));
		board[4][3] = secondPlayer.getTeam().get(2);
		}
	
		*/
		
		//firstPlayer.getLeader().setLocation(new Point(0,2));
		//board[0][2] = firstPlayer.getTeam().get(0);
		
		//if(firstPlayer.getTeam().get(0)!=null && !(firstPlayer.getTeam().get(0).getName().equals(firstPlayer.getLeader().getName())))
		
			for (int i=0; i< firstPlayer.getTeam().size(); i++ )
			{
				//if (board[0][i+1] ==null  &&!(firstPlayer.getTeam().get(i).getName().equals(firstPlayer.getLeader().getName()))){
				
				firstPlayer.getTeam().get(i).setLocation(new Point(0,i+1));
				board[0][i+1] = firstPlayer.getTeam().get(i);
			//}
				}
		//firstPlayer.getTeam().get(0).setLocation(new Point(0,1));
		//board[0][1] = firstPlayer.getTeam().get(0);
				//secondPlayer.getLeader().setLocation(new Point(4,2));
				//board[4][2] = secondPlayer.getTeam().get(0);
				for (int j=0; j< secondPlayer.getTeam().size(); j++ )
				{
					//if (board[4][j+1] ==null  &&!(secondPlayer.getTeam().get(j).getName().equals(secondPlayer.getLeader().getName()))){
						secondPlayer.getTeam().get(j).setLocation(new Point(BOARDHEIGHT-1,j+1));
					board[BOARDHEIGHT-1][j+1] = secondPlayer.getTeam().get(j);
				//}
					}	
			}	
		/*if (firstPlayer.getTeam().get(1)!= null)
		{
		firstPlayer.getTeam().get(1).setLocation(new Point(0,2));
		board[0][2] = firstPlayer.getTeam().get(1);
		}
		if (firstPlayer.getTeam().get(2)!= null)
		{
		firstPlayer.getTeam().get(2).setLocation(new Point(0,3));
		board[0][3] = firstPlayer.getTeam().get(2);
		}
		if(secondPlayer.getTeam().get(0)!= null)
		{
		secondPlayer.getTeam().get(0).setLocation(new Point(4,1));
		board[4][1] = secondPlayer.getTeam().get(0);
		}
		if (secondPlayer.getTeam().get(1)!= null)
		{
		secondPlayer.getTeam().get(1).setLocation(new Point(4,2));
		board[4][2] = secondPlayer.getTeam().get(1);
		}
		if (secondPlayer.getTeam().get(2)!= null)
		{
		secondPlayer.getTeam().get(2).setLocation(new Point(4,3));
		board[4][3] = secondPlayer.getTeam().get(2);
		}
		
	}*/
	/*private void placeChampions()
	{
		board[0][1] = firstPlayer.getLeader();
		board[BOARDHEIGHT-2][1] = secondPlayer.getLeader();
		int a = 2;
		//int b = BOARDHEIGHT-2; 
		for(int j =0;j<(firstPlayer.getTeam()).size();j++){
			board[0][a] = firstPlayer.getTeam().get(j);
			if (a<(firstPlayer.getTeam()).size())
			{
				a++;
			}
		}
		a =2 ;
		for(int k =0;k<(secondPlayer.getTeam()).size();k++){
			board[BOARDHEIGHT-1][a] = secondPlayer.getTeam().get(k);
			if (a<(secondPlayer.getTeam()).size())
			{
				a++;
			}
		} ++
		
	}*/
	private void placeCovers()
	{
		Random r = new Random();
		int c1 = r.nextInt(BOARDHEIGHT-2)+1;
		int c2 = r.nextInt(BOARDWIDTH);
		/*while(c1 == 0 || c1 == 4)
		{
			c1 = r.nextInt(5);
		}
		while(c2 == 0 || c2 == 4)
		{
			c2 = r.nextInt(5);
		}*/
		/*while (c1 == 0 || c1 == BOARDHEIGHT-1)
		{
			c1 = r.nextInt(BOARDHEIGHT-2)+1;
		}*/
		/*while (c2 == 0 || c2 == 4)
		{
			c2 = r.nextInt(5);
		}*/
		for (int i=0; i<5; i++)
		{
		while ((board[c1][c2] != null))
		{
			c1 = r.nextInt(BOARDHEIGHT-2)+1;
			/*while(c1 == 0 || c1 == BOARDHEIGHT-1)
			{
				c1 = r.nextInt(BOARDHEIGHT-2)+1;
			}*/
			if ((board[c1][c2] != null))
			{
				c2 = r.nextInt(BOARDWIDTH);
			/*while(c2 == 0 || c2 == 4)
			{
				c2 = r.nextInt(5);
			}*/
			}
			/*if ((board[c1][c2] == null))
			c1 = r.nextInt(5);
			c2 = r.nextInt(5);*/
		}
		Cover c = new Cover(c1,c2);
		c.getLocation().x = c1;
		c.getLocation().y = c2;
		board[c1][c2] = c;
		//board[c1][c2] = new Cover(c1,c2);
		//c1 = 0;
		//c2 = 0;
		//int[] a = new int[5];
		//a[3] = 5;
		
		}
	}
	
	
		// loadAbilities converts arraylist of strings to arraylist of objects
		
	public static  void loadAbilities(String filepath) throws IOException
		{
			String line;
			BufferedReader br = null;
			//ArrayList<String> s =  new ArrayList<>();
			
				br = new BufferedReader(new FileReader(filepath));
		while((line = br.readLine())!= null){
					//s.add(line);
					
				

			
			String[] parr = new String[9];
			
			
			//declarations of attributes
			String Type,name,effectName,AreaofEffect;
			
			int manaCost,castRange,baseCooldown,requiredActionsPerTurn,damageAmount,healAmount,effectDuration;
			
			
			//for(int i =0;i<s.size();i++)
			//{
				//line = s.get(i); // "X,Y,Z"
				parr = line.split(",");
				Type = parr[0];
				name = parr[1];
				manaCost = Integer.parseInt(parr[2]);
				castRange = Integer.parseInt(parr[3]);
				baseCooldown = Integer.parseInt(parr[4]);
				requiredActionsPerTurn = Integer.parseInt(parr[6]);
				AreaOfEffect a = AreaOfEffect.valueOf(parr[5]);
				
				if(Type.equals("DMG")) {
					 damageAmount = Integer.parseInt(parr[7]);
					 availableAbilities.add(new DamagingAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,damageAmount));
				}
				else if(Type.equals("HEL")) {
					healAmount = Integer.parseInt(parr[7]);
					availableAbilities.add(new HealingAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,healAmount));
			
				}
				else if (Type.equals("CC"))
				{
			    	effectName = parr[7];
			    	effectDuration = Integer.parseInt( parr[8]);//String name, int manaCost, int baseCooldown, int castRange, AreaOfEffect castArea,
					//int requiredActionPoints, Effect effect)//	public Effect(String name, int duration, EffectType type)
					switch(effectName) {
					case "Disarm" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Disarm(effectDuration)));break;
					case "PowerUp" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new PowerUp(effectDuration)));break;
					case "Shield" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Shield(effectDuration)));break;
					case "Silence" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Silence(effectDuration)));break;
					case "SpeedUp" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new SpeedUp(effectDuration)));break;
					case "Embrace" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Embrace(effectDuration)));break;
					case "Root" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Root(effectDuration)));break;
					case "Shock" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Shock(effectDuration)));break;
					case "Dodge" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Dodge(effectDuration)));break;
					case "Stun" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Stun(effectDuration)));break;
					
					
					}
					/*switch(effectName) {
					case "Disarm" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.DEBUFF)));break;
					case "PoweUp" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.BUFF)));break;
					case "Shield" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.BUFF)));break;
					case "Silence" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.DEBUFF)));break;
					case "SpeedUp" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.BUFF)));break;
					case "Embrace" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.BUFF)));break;
					case "Root" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.DEBUFF)));break;
					case "Shock" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.DEBUFF)));break;
					case "Dodge" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.BUFF)));break;
					case "Stun" :availableAbilities.add(new CrowdControlAbility(name,manaCost,baseCooldown,castRange,a,requiredActionsPerTurn,new Effect(effectName,effectDuration,EffectType.DEBUFF)));break;
					
					
					}
					 */	
				}
				
				

				}
		//	}
				
					
				
					
			}
			
			
			public static void loadChampions (String filePath) throws IOException{
				String line="";
				BufferedReader br= null;
				//ArrayList<String> S=new ArrayList<>();
				
					br= new BufferedReader(new FileReader(filePath));
					while( (line=br.readLine()) !=null){
						//S.add(line);
						String[] parr=line.split(",");
						String Type,name,ability1Name,ability2Name,ability3Name;
						int maxHP, mana, actions,speed, attackRange, attackDamage;
						Type=parr[0];
						name=parr[1];
						maxHP=Integer.parseInt(parr[2]);
						mana=Integer.parseInt(parr[3]);
						actions=Integer.parseInt(parr[4]);
						speed=Integer.parseInt(parr[5]);
						attackRange=Integer.parseInt(parr[6]);
						attackDamage=Integer.parseInt(parr[7]);
						ability1Name=parr[8];
						ability2Name=parr[9];
						ability3Name=parr[10];
						
						Ability a1=Helper(ability1Name);
						Ability a2=Helper(ability2Name);
						Ability a3=Helper(ability3Name);
						Champion C = null;
						if(Type.equals("A")){
							C=new AntiHero(name,maxHP,mana,actions,speed,
									attackRange,attackDamage);
							C.getAbilities().add(a1);
							C.getAbilities().add(a2);
							C.getAbilities().add(a3);
							

						}
						else
							if(Type.equals("H")){
								C=new Hero(name,maxHP,mana,actions,speed,
										attackRange,attackDamage);
								C.getAbilities().add(a1);
								C.getAbilities().add(a2);
								C.getAbilities().add(a3);



							}
							else{
								if(Type.equals("V"))
								C=new Villain(name,maxHP,mana,actions,speed,
										attackRange,attackDamage);
								C.getAbilities().add(a1);
								C.getAbilities().add(a2);
								C.getAbilities().add(a3);

							}
						availableChampions.add(C);	
					}
				/*finally{
					br.close();
				}*/
				//Split the String line by comma
				/*String Type,name,ability1Name,ability2Name,ability3Name;
				int maxHP, mana, actions,speed, attackRange, attackDamage;
				for(int i=0;i<S.size();i++){
					linee=S.get(i);
					parr=line.split(",");
					Type=parr[0];
					name=parr[1];
					maxHP=Integer.parseInt(parr[2]);
					mana=Integer.parseInt(parr[3]);
					actions=Integer.parseInt(parr[4]);
					speed=Integer.parseInt(parr[5]);
					attackRange=Integer.parseInt(parr[6]);
					attackDamage=Integer.parseInt(parr[7]);
					ability1Name=parr[8];
					ability2Name=parr[9];
					ability3Name=parr[10];

					if(Type.equals("A")){
						availableChampions.add(new AntiHero(name,maxHP,mana,actions,speed,
								attackRange,attackDamage));

					}
					else
						if(Type.equals("H")){
							availableChampions.add(new Hero(name,maxHP,mana,actions,speed,
									attackRange,attackDamage));



						}
						else{
							availableChampions.add(new Villain(name,maxHP,mana,actions,speed,
									attackRange,attackDamage));

						}
					ArrayList<Ability> tmp=availableChampions.get(i).getAbilities();
					for(int j=0;j<availableAbilities.size();j++){
						Ability a=availableAbilities.get(j);
						if(a.getName().equals(ability1Name))
							tmp.add(a);
						else
							if(a.getName().equals(ability2Name))
								tmp.add(a);
							else
								if(a.getName().equals(ability3Name))
									tmp.add(a);
					}
					

				}*/
 
}
				
    private static Ability Helper(String s){
    	for(int i=0;i<availableAbilities.size();i++){
    		if(availableAbilities.get(i).getName().equals(s))
    			return availableAbilities.get(i);
   
    		}
    	return null;
    }
				
	//GETTERS AND SETTERS
	public Player getFirstPlayer() {
		return firstPlayer;
	}

	public Player getSecondPlayer() {
		return secondPlayer;
	}

	public boolean isFirstLeaderAbilityUsed() {
		return firstLeaderAbilityUsed;
	}

	public boolean isSecondLeaderAbilityUsed() {
		return secondLeaderAbilityUsed;
	}

	public Object[][] getBoard() {
		return board;
	}

	public static ArrayList<Champion> getAvailableChampions() {
		return availableChampions;
	}

	public static ArrayList<Ability> getAvailableAbilities() {
		return availableAbilities;
	}

	public PriorityQueue getTurnOrder() {
		return turnOrder;
	}

	public static final int getBoardheight() {
		return BOARDHEIGHT;
	}

	public static final int getBoardwidth() {
		return BOARDWIDTH;
	}

	/*public static int getBOARDHEIGHT() {
		return BOARDHEIGHT;
	}

	public static int getBOARDWIDTH() {
		return BOARDWIDTH;
	}*/
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	 
}
